from django.shortcuts import render, redirect
from django.http import HttpResponse
from authentication.models import User_Registration, User_OTP, User_TemperoryModel, Vendor_Registration, Vendor_OTP, Vendor_TemperoryModel
from django.contrib.auth import authenticate, login, logout
from users.models import User
from rest_framework.authtoken.models import Token
import http.client
from django.contrib.auth.tokens import default_token_generator
import random
from django.conf import settings
from django.shortcuts import get_object_or_404

def send_otp(mobile, otp):
    conn = http.client.HTTPSConnection("api.msg91.com")
    authkey = settings.AUTH_KEY 
    headers = { 'content-type': "application/json" }
    space=" "
    url = f'http://control.msg91.com/api/sendotp.php?otp={otp}&message=Please_verify_your_otp_{otp}&mobile={mobile}&authkey={authkey}&country=91'
    conn.request("GET", url , headers=headers)
    res = conn.getresponse()
    data = res.read()
    print(data)
    return None

def register(request):
    if request.method=='POST':
        email = request.POST.get('email','')
        phone = request.POST.get('phone','')
        password = request.POST.get('password','')
        confirm_password = request.POST.get('confirm_password','')
        first_name = request.POST.get('first_name','')
        last_name = request.POST.get('last_name','')
        city = request.POST.get('city','')
        state = request.POST.get('state','')
        zipcode = request.POST.get('zipcode','')
        country = request.POST.get('country','')
        latitude = request.POST.get('latitude',0.0)
        longitude = request.POST.get('longitude',0.0)
        referralCode = request.POST.get('referralCode','')
        user_exs = User.objects.filter(phone = phone, is_active = True).exists()
        if user_exs:
            print('helllo user')
            print(user_exs)
            return render(request,'user/index.html',{'msg':'Email or Phone number already taken'})
        user_exs = User.objects.filter(email = email, phone = phone, is_active = True).exists()
        print(user_exs)
        if user_exs:
            print('helllo user')
            print(user_exs)
            return render(request,'user/index.html',{'msg':'Email or Phone number already taken'})
        if password == confirm_password:
            try:
                print('48')
                user = User.objects.create_user(email = email, phone = phone, password= password, first_name = first_name, last_name = last_name, is_active = False)
                print(user)
                print('50')
                x = User_TemperoryModel.objects.create(user = user,city = city, state = state, zipcode = zipcode, country = country)
                print('jitendra')
                x.save()
                print('meena')
                otp_gen= str(random.randint(1000,9999))
                otp_obj = User_OTP(user = x, phone = phone, otp_num = otp_gen)
                otp_obj.save()
                if otp_obj is not None:
                    request.session['mobile'] = phone
                    send_otp(phone, otp_gen)
                    return redirect('/otp/')
            except Exception as e:
                print(e)
                print('65')
                print(phone)
                try:
                    user_obj = get_object_or_404(User, phone = phone)
                    print('phone verified')
                except Exception as e:
                    print(e)
                    user_obj = get_object_or_404(User, email = email)
                    print('hello user')
                print('68')
                user_obj.delete()
                user = User.objects.create_user(email = email, phone = phone, password = password, first_name = first_name, last_name = last_name, is_active = False)
                print(user)
                x = User_TemperoryModel.objects.create(user = user,city = city, state = state, zipcode = zipcode, country = country)
                print('jitendra')
                x.save()
                print('meena')
                otp_gen = str(random.randint(1000,9999))
                otp_obj = User_OTP(user = x, phone = phone, otp_num = otp_gen)
                otp_obj.save()
                if otp_obj is not None:
                    request.session['mobile'] = phone
                    send_otp(phone, otp_gen)
                    return redirect('/otp/')
                # return render(request,'user/index.html',{'msg':'Re-Enter your details'})
        else:
            return render(request,'user/index.html',{'error':'password not matched'})
    else:
        if request.user.is_authenticated:
            return render(request,'home.html')
        return render(request,'user/index.html')

def loginnow(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        try :
            echeck = get_object_or_404(Vendor_Registration, vuser__email = email)
            print(echeck)
            print('Jai ambey mata')
            return render(request,'user/login.html', {'msg' : 'Already Registered for Vendor'})
        except Exception as e:
            print('Jai bhawani')
            print(e)
        user = authenticate(request, email = email, password = password)
        print(user)
        if user is not None:
            login(request, user)
            token, created = Token.objects.get_or_create(user=user)
            return render(request,'home.html')
        else:
            return render(request,'user/login.html')
    else:
        if request.user.is_authenticated:
            return render(request, 'home.html')
        return render(request,'user/login.html')



def otp_verify(request):
    if request.method == 'POST':
        phone = request.session['mobile']
        user_otp = request.POST.get('otp')
        try:
            otp_obj = get_object_or_404(User_OTP, phone=phone)
        except Exception as e:
            print(e)
            return render(request,'user/otp.html',{'msg':'Incorrect OTP'})
        db_otp = otp_obj.otp_num
        if db_otp == user_otp:
            print(otp_obj.user.id)
            
            #Fetching data from temperory table and then putting it into the Registration table
            # 1.Temp Table

            temp_obj = get_object_or_404(User_TemperoryModel,id=otp_obj.user.id)
            user_phone = temp_obj.user.phone
            user = get_object_or_404(User,phone = user_phone)
            user.is_active = True

            user.save()
            user_ct = temp_obj.city
            user_st = temp_obj.state
            user_zp = temp_obj.zipcode
            user_cn = temp_obj.country

            # 2. Main Table
            register = User_Registration(user = user, city= user_ct, state = user_st, zipcode = user_zp, country = user_cn)
            register.save()
            # temp_obj.delete()
            return render(request,'user/login.html')
        else:
            return render(request,'user/otp.html',{'msg':'Wrong OTP! Please enter correct OTP'})
    else:
        if request.user.is_authenticated:
            return redirect('/home/')
        return render(request,'user/otp.html',{'msg':'Please verify your otp'})

def logoutnow(request):
    if request.method == 'POST':
        logout(request)
        return render(request, 'user/login.html')
    else:
        if request.user.is_authenticated:
            return redirect('/home/')
        return render(request, 'user/index.html')

def resend_otp(request):
    if request.method == 'GET':
        phone = request.session['mobile']
        otp_gen = str(random.randint(1000,9999))
        try:
            otp_obj = get_object_or_404(User_OTP, phone=phone)
        except Exception as e:
            print(e)
        otp_obj.otp_num = otp_gen
        otp_obj.save()
        send_otp(phone, otp_gen)
        return render(request,'user/resend_otp.html',{'msg':'Sent Successfully'})
    elif request.method == 'POST':
        otp_verify(request)
        if request.user.is_authenticated:
            return render(request,'user/login.html',{'msg':'Successfully'})
        else:
            return render(request,'user/otp.html',{'msg':'Wrong OTP'})

#Views for Vendor

def vendorregister(request):
    if request.method=='POST':
        email = request.POST.get('email','')
        phone = request.POST.get('phone','')
        password = request.POST.get('password','')
        confirm_password = request.POST.get('confirm_password','')
        first_name = request.POST.get('first_name','')
        last_name = request.POST.get('last_name','')
        city = request.POST.get('city','')
        state = request.POST.get('state','')
        zipcode = request.POST.get('zipcode','')
        country = request.POST.get('country','')
        latitude = request.POST.get('latitude',0.0)
        longitude = request.POST.get('longitude',0.0)
        referralCode = request.POST.get('referralCode','')
        user_exs = User.objects.filter(phone = phone, is_active = True).exists()
        if user_exs:
            print('helllo user')
            print(user_exs)
            return render(request,'vendor/index.html',{'msg':'Email or Phone number already taken'})
        user_exs = User.objects.filter(email = email, phone = phone, is_active = True).exists()
        print(user_exs)
        if user_exs:
            print('helllo user')
            print(user_exs)
            return render(request,'vendor/index.html',{'msg':'Email or Phone number already taken'})
        if password == confirm_password:
            try:
                print('48')
                user = User.objects.create_user(email = email, phone = phone, password= password, first_name = first_name, last_name = last_name, is_active = False)
                print(user)
                print('50')
                x = Vendor_TemperoryModel.objects.create(user = user,city = city, state = state, zipcode = zipcode, country = country)
                print('jitendra')
                x.save()
                print('meena')
                otp_gen= str(random.randint(1000,9999))
                otp_obj = Vendor_OTP(user = x, phone = phone, otp_num = otp_gen)
                otp_obj.save()
                if otp_obj is not None:
                    request.session['mobile'] = phone
                    send_otp(phone, otp_gen)
                    return redirect('/vendorotp/')
            except Exception as e:
                print(e)
                print('65')
                print(phone)
                try:
                    user_obj = get_object_or_404(User, phone = phone)
                    print('phone verified')
                except Exception as e:
                    print(e)
                    user_obj = get_object_or_404(User, email = email)
                    print('hello user')
                print('68')
                user_obj.delete()
                user = User.objects.create_user(email = email, phone = phone, password = password, first_name = first_name, last_name = last_name, is_active = False)
                print(user)
                x = Vendor_TemperoryModel.objects.create(user = user,city = city, state = state, zipcode = zipcode, country = country)
                print('jitendra')
                x.save()
                print('meena')
                otp_gen = str(random.randint(1000,9999))
                otp_obj = Vendor_OTP(user = x, phone = phone, otp_num = otp_gen)
                otp_obj.save()
                if otp_obj is not None:
                    request.session['mobile'] = phone
                    send_otp(phone, otp_gen)
                    return redirect('/vendorotp/')
                # return render(request,'user/index.html',{'msg':'Re-Enter your details'})
        else:
            return render(request,'vendor/index.html',{'error':'password not matched'})
    else:
        if request.user.is_authenticated:
            return render(request,'home.html')
        return render(request,'vendor/index.html')

def vendorloginnow(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        
        try :
            echeck = get_object_or_404(User_Registration, user__email = email)
            print(echeck)
            print('hanuman')
            return render(request,'vendor/login.html', {'msg' : 'Already Registered for User'})
        except Exception as e:
            print('ram')
            print(e)
        user = authenticate(request, email = email, password = password)
        print(user)
        if user is not None:
            login(request, user)
            token, created = Token.objects.get_or_create(user=user)
            return redirect('/core/home/')
        else:
            return redirect('vendorlogin')
    else:
        if request.user.is_authenticated:
            return render(request, 'home.html')
        return render(request,'vendor/login.html')

# def home(request):
#     if request.user.is_authenticated:
#         return render(request, 'home.html')
#     else:
#         return render(request, 'user/login.html')

def vendorotp_verify(request):
    if request.method == 'POST':
        phone = request.session['mobile']
        user_otp = request.POST.get('otp')
        try:
            otp_obj = get_object_or_404(Vendor_OTP, phone=phone)
        except Exception as e:
            print(e)
            return render(request,'vendor/otp.html',{'msg':'Incorrect OTP'})
        db_otp = otp_obj.otp_num
        if db_otp == user_otp:
            print(otp_obj.user.id)
            
            #Fetching data from temperory table and then putting it into the Registration table
            # 1.Temp Table

            temp_obj = get_object_or_404(Vendor_TemperoryModel,id=otp_obj.user.id)
            user_phone = temp_obj.user.phone
            user = get_object_or_404(User,phone = user_phone)
            user.is_active = True

            user.save()
            user_ct = temp_obj.city
            user_st = temp_obj.state
            user_zp = temp_obj.zipcode
            user_cn = temp_obj.country

            # 2. Main Table
            register = Vendor_Registration(user = user, city= user_ct, state = user_st, zipcode = user_zp, country = user_cn)
            register.save()
            # temp_obj.delete()
            return render(request,'vendor/login.html')
        else:
            return render(request,'vendor/otp.html',{'msg':'Wrong OTP! Please enter correct OTP'})
    else:
        if request.user.is_authenticated:
            return redirect('/home/')
        return render(request,'vendor/otp.html',{'msg':'Please verify your otp'})

def vendorlogoutnow(request):
    if request.method == 'POST':
        logout(request)
        return render(request, 'vendor/login.html')
    else:
        if request.user.is_authenticated:
            return redirect('/home/')
        return render(request, 'vendor/index.html')

def vendorresend_otp(request):
    if request.method == 'GET':
        phone = request.session['mobile']
        otp_gen = str(random.randint(1000,9999))
        try:
            otp_obj = get_object_or_404(Vendor_OTP, phone=phone)
        except Exception as e:
            print(e)
        otp_obj.otp_num = otp_gen
        otp_obj.save()
        send_otp(phone, otp_gen)
        return render(request,'vendor/resend_otp.html',{'msg':'Sent Successfully'})
    elif request.method == 'POST':
        otp_verify(request)
        if request.user.is_authenticated:
            return render(request,'vendor/login.html',{'msg':'Successfully'})
        else:
            return render(request,'vendor/otp.html',{'msg':'Wrong OTP'})


              
#  ADMIN_Login
