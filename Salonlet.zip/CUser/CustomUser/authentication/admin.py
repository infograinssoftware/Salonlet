from django.contrib import admin
from .models import User_Registration, User_OTP, User_TemperoryModel, Vendor_Registration, Vendor_TemperoryModel, Vendor_OTP

# admin.site.register(Registration)
# admin.site.register(OTP)


@admin.register(User_Registration)
class User_Registrationadmin(admin.ModelAdmin):
    list_display = ['user','profile_pic','city','zipcode','state','country','latitude','longitude','referralCode']

    
@admin.register(User_TemperoryModel)
class User_TemperoryModeladmin(admin.ModelAdmin):
    list_display = ['user','profile_pic','city','zipcode','state','country','latitude','longitude','referralCode']


@admin.register(User_OTP)
class User_OTPadmin(admin.ModelAdmin):
    list_display=['user','phone','otp_num']

@admin.register(Vendor_Registration)
class Vendor_Registrationadmin(admin.ModelAdmin):
    list_display = ['vuser','profile_pic','city','zipcode','state','country','latitude','longitude','referralCode']

    
@admin.register(Vendor_TemperoryModel)
class Vendor_TemperoryModeladmin(admin.ModelAdmin):
    list_display = ['vuser','profile_pic','city','zipcode','state','country','latitude','longitude','referralCode']


@admin.register(Vendor_OTP)
class Vendor_OTPadmin(admin.ModelAdmin):
    list_display=['vuser','phone','otp_num']
