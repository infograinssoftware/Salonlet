from django.urls import path
from authentication.views import register, loginnow , otp_verify, logoutnow, resend_otp, vendorregister, vendorloginnow, vendorlogoutnow, vendorotp_verify, vendorresend_otp
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth import views as auth_views
urlpatterns = [
    #User's EndPoints
    path('userregister/',csrf_exempt(register),name='userregister'),
    path('userlogin/',csrf_exempt(loginnow),name='userlogin'),
    path('userlogout/',logoutnow,name='logout'),
    path('otp/',otp_verify,name='otp_verify'),
    path('resendotp/',resend_otp,name='resend_otp'),


    #Vendor's EndPoints
    path('vendorregister/',csrf_exempt(vendorregister),name='vendorregister'),
    path('vendorlogin/',csrf_exempt(vendorloginnow),name='vendorlogin'),
    path('vendorlogout/',vendorlogoutnow,name='vendorlogout'),
    path('vendorotp/',vendorotp_verify,name='vendorotp'),
    path('vendorresendotp/',vendorresend_otp,name='vendorresendotp'),


    # Forget Password
    path('password-reset/',
         auth_views.PasswordResetView.as_view(
             template_name='password_reset.html',
             subject_template_name='password_reset_subject.txt',
             email_template_name='password_reset_email.html',
             # success_url='/login/'
         ),
         name='password_reset'),
    path('password-reset/done/',
         auth_views.PasswordResetDoneView.as_view(
             template_name='password_reset_done.html'
         ),
         name='password_reset_done'),
    path('password-reset-confirm/<uidb64>/<token>/',
         auth_views.PasswordResetConfirmView.as_view(
             template_name='password_reset_confirm.html'
         ),
         name='password_reset_confirm'),
    path('password-reset-complete/',
         auth_views.PasswordResetCompleteView.as_view(
             template_name='password_reset_complete.html'
         ),
         name='password_reset_complete'),
]